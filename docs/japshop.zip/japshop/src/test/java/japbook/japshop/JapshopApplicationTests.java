package japbook.japshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JapshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
